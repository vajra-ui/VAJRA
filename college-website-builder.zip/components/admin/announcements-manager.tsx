"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Megaphone, Trash2 } from "lucide-react"

interface Announcement {
  id: string
  title: string
  content: string
  priority: string
  is_active: boolean
  created_at: string
}

export function AnnouncementsManager({ announcements }: { announcements: Announcement[] }) {
  const [showForm, setShowForm] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)

    const formData = new FormData(e.currentTarget)
    const announcementData = {
      title: formData.get("title") as string,
      content: formData.get("content") as string,
      priority: formData.get("priority") as string,
      is_active: true,
    }

    const { error } = await supabase.from("announcements").insert([announcementData])

    if (error) {
      alert("Error adding announcement")
    } else {
      setShowForm(false)
      router.refresh()
    }
    setIsLoading(false)
  }

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this announcement?")) return

    const { error } = await supabase.from("announcements").delete().eq("id", id)
    if (!error) router.refresh()
  }

  const priorityColors = {
    low: "bg-gray-100 text-gray-600",
    normal: "bg-blue-100 text-blue-600",
    high: "bg-orange-100 text-orange-600",
    urgent: "bg-red-100 text-red-600",
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <Button onClick={() => setShowForm(!showForm)}>
          <Plus className="mr-2 h-4 w-4" />
          New Announcement
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Create Announcement</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Title *</Label>
                <Input id="title" name="title" required placeholder="Important announcement" />
              </div>
              <div>
                <Label htmlFor="content">Content *</Label>
                <Textarea id="content" name="content" required placeholder="Announcement details" rows={4} />
              </div>
              <div>
                <Label htmlFor="priority">Priority</Label>
                <select id="priority" name="priority" className="w-full p-2 border rounded-md" defaultValue="normal">
                  <option value="low">Low</option>
                  <option value="normal">Normal</option>
                  <option value="high">High</option>
                  <option value="urgent">Urgent</option>
                </select>
              </div>
              <div className="flex gap-4">
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? "Posting..." : "Post Announcement"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="space-y-4">
        {announcements.map((announcement) => (
          <Card key={announcement.id}>
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <Megaphone className="h-5 w-5 text-blue-600" />
                    <h3 className="text-lg font-semibold">{announcement.title}</h3>
                    <span
                      className={`px-2 py-1 rounded text-xs ${priorityColors[announcement.priority as keyof typeof priorityColors]}`}
                    >
                      {announcement.priority}
                    </span>
                  </div>
                  <p className="text-gray-700 mb-2">{announcement.content}</p>
                  <p className="text-xs text-gray-500">
                    Posted on {new Date(announcement.created_at).toLocaleDateString()}
                  </p>
                </div>
                <Button size="sm" variant="destructive" onClick={() => handleDelete(announcement.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
