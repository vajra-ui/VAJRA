"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export function AddStudentForm() {
  const router = useRouter()
  const supabase = createClient()
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsLoading(true)

    const formData = new FormData(e.currentTarget)
    const studentData = {
      roll_number: formData.get("roll_number") as string,
      name: formData.get("name") as string,
      email: formData.get("email") as string,
      year: Number.parseInt(formData.get("year") as string),
      section: formData.get("section") as string,
      phone: formData.get("phone") as string,
      parent_phone: formData.get("parent_phone") as string,
      address: formData.get("address") as string,
      cgpa: Number.parseFloat(formData.get("cgpa") as string) || 0,
    }

    const { error } = await supabase.from("students").insert([studentData])

    if (error) {
      alert("Error adding student: " + error.message)
      setIsLoading(false)
    } else {
      router.push("/admin/students")
    }
  }

  return (
    <Card>
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="roll_number">Roll Number *</Label>
              <Input id="roll_number" name="roll_number" required placeholder="e.g., 21CSE001" />
            </div>
            <div>
              <Label htmlFor="name">Full Name *</Label>
              <Input id="name" name="name" required placeholder="Student full name" />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input id="email" name="email" type="email" required placeholder="student@example.com" />
            </div>
            <div>
              <Label htmlFor="phone">Phone</Label>
              <Input id="phone" name="phone" type="tel" placeholder="+91-9876543210" />
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="year">Year *</Label>
              <Input id="year" name="year" type="number" min="1" max="4" required placeholder="1-4" />
            </div>
            <div>
              <Label htmlFor="section">Section</Label>
              <Input id="section" name="section" placeholder="A" />
            </div>
            <div>
              <Label htmlFor="cgpa">CGPA</Label>
              <Input id="cgpa" name="cgpa" type="number" step="0.01" min="0" max="10" placeholder="0.00" />
            </div>
          </div>

          <div>
            <Label htmlFor="parent_phone">Parent Phone</Label>
            <Input id="parent_phone" name="parent_phone" type="tel" placeholder="+91-9876543210" />
          </div>

          <div>
            <Label htmlFor="address">Address</Label>
            <Input id="address" name="address" placeholder="Full address" />
          </div>

          <div className="flex gap-4">
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Adding..." : "Add Student"}
            </Button>
            <Button type="button" variant="outline" onClick={() => router.back()}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
