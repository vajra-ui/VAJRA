"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

export function SiteHeader() {
  const [isOpen, setIsOpen] = useState(false)

  const navItems = [
    { name: "Home", href: "#home" },
    { name: "About", href: "#about" },
    { name: "Programs", href: "#programs" },
    { name: "Faculty", href: "#faculty" },
    { name: "Research", href: "#research" },
    { name: "Placements", href: "#placements" },
    { name: "Contact", href: "#contact" },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b border-primary/20 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      <div className="container mx-auto flex h-14 md:h-16 items-center justify-between px-3 sm:px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 md:h-10 md:w-10 items-center justify-center rounded-lg bg-primary">
            <span className="text-sm md:text-lg font-bold text-primary-foreground">CSE</span>
          </div>
          <div className="hidden sm:block">
            <h1 className="text-sm md:text-base lg:text-lg font-bold text-foreground leading-tight">
              Paavai Engineering College
            </h1>
            <p className="text-[10px] md:text-xs text-muted-foreground leading-tight">
              Department of Computer Science and Engineering
            </p>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-4 xl:gap-6">
          {navItems.map((item) => (
            <a
              key={item.name}
              href={item.href}
              className="text-xs xl:text-sm font-medium text-foreground hover:text-primary transition-colors"
            >
              {item.name}
            </a>
          ))}
          <Link href="/admin/login">
            <Button
              size="sm"
              variant="outline"
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent text-xs"
            >
              Admin
            </Button>
          </Link>
        </nav>

        <button className="lg:hidden text-foreground p-2" onClick={() => setIsOpen(!isOpen)} aria-label="Toggle menu">
          {isOpen ? <X className="h-5 w-5 md:h-6 md:w-6" /> : <Menu className="h-5 w-5 md:h-6 md:w-6" />}
        </button>
      </div>

      {isOpen && (
        <div className="lg:hidden border-t border-primary/20 bg-background">
          <nav className="flex flex-col gap-3 p-4 max-h-[calc(100vh-3.5rem)] overflow-y-auto">
            {navItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="text-sm font-medium text-foreground hover:text-primary py-2"
                onClick={() => setIsOpen(false)}
              >
                {item.name}
              </a>
            ))}
            <Link href="/admin/login" onClick={() => setIsOpen(false)}>
              <Button
                size="sm"
                variant="outline"
                className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
              >
                Admin Login
              </Button>
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}
