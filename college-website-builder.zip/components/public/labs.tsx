"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Server, Code, Brain, Shield, Database, Cloud } from "lucide-react"
import dynamic from "next/dynamic"

const ElectricBorder = dynamic(() => import("@/components/animations/ElectricBorder"), { ssr: false })

export function Labs() {
  const labs = [
    {
      name: "Programming Lab",
      icon: Code,
      description: "150 systems with latest IDEs and development tools",
    },
    {
      name: "AI & ML Lab",
      icon: Brain,
      description: "GPUs and specialized hardware for deep learning projects",
    },
    {
      name: "Networking Lab",
      icon: Server,
      description: "Cisco certified lab with routers and switches",
    },
    {
      name: "Cybersecurity Lab",
      icon: Shield,
      description: "Ethical hacking and security testing environment",
    },
    {
      name: "Database Lab",
      icon: Database,
      description: "Oracle, MySQL, MongoDB for database management",
    },
    {
      name: "Cloud Computing Lab",
      icon: Cloud,
      description: "AWS, Azure, GCP access for cloud projects",
    },
  ]

  return (
    <section className="py-12 md:py-16 bg-black border-y border-primary/20">
      <div className="mx-auto max-w-3xl text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-bold text-primary mb-3 text-balance">State-of-the-Art Laboratories</h2>
        <p className="text-base text-foreground/70 text-pretty">
          Modern facilities equipped with the latest technology for hands-on learning
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {labs.map((lab, index) => {
          const Icon = lab.icon
          return (
            <ElectricBorder key={index} color="#D4AF37" speed={1} chaos={0.3} thickness={2} style={{ borderRadius: 8 }}>
              <Card className="hover:shadow-lg hover:shadow-primary/20 transition-all bg-transparent border-0 h-full">
                <CardContent className="p-5">
                  <div className="flex items-start gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-transparent border-2 border-primary/50">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-base font-semibold mb-1.5 text-primary">{lab.name}</h3>
                      <p className="text-sm text-foreground/70">{lab.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </ElectricBorder>
          )
        })}
      </div>
    </section>
  )
}
