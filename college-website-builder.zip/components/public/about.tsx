import { Card } from "@/components/ui/card"
import { BookOpen, Lightbulb, Target, Users } from "lucide-react"

export function About() {
  return (
    <section id="about" className="py-12 md:py-16">
      <div className="mx-auto max-w-3xl text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-bold text-primary mb-3 text-balance">About Our Department</h2>
        <p className="text-base text-foreground/80 text-pretty">
          The Department of Computer Science and Engineering at Paavai Engineering College is committed to providing
          quality education and fostering innovation. Established with a vision to create competent engineers, we focus
          on academic excellence, research, and industry collaboration.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-5 text-center bg-transparent border-2 border-primary/50 hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all">
          <div className="flex justify-center mb-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-transparent border-2 border-primary/50">
              <BookOpen className="h-6 w-6 text-primary" />
            </div>
          </div>
          <h3 className="text-base font-semibold mb-2 text-primary">Quality Education</h3>
          <p className="text-sm text-foreground/70">
            Updated curriculum aligned with industry standards and emerging technologies
          </p>
        </Card>

        <Card className="p-5 text-center bg-transparent border-2 border-primary/50 hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all">
          <div className="flex justify-center mb-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-transparent border-2 border-primary/50">
              <Lightbulb className="h-6 w-6 text-primary" />
            </div>
          </div>
          <h3 className="text-base font-semibold mb-2 text-primary">Innovation Hub</h3>
          <p className="text-sm text-foreground/70">
            State-of-the-art labs and research facilities for hands-on learning
          </p>
        </Card>

        <Card className="p-5 text-center bg-transparent border-2 border-primary/50 hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all">
          <div className="flex justify-center mb-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-transparent border-2 border-primary/50">
              <Users className="h-6 w-6 text-primary" />
            </div>
          </div>
          <h3 className="text-base font-semibold mb-2 text-primary">Expert Faculty</h3>
          <p className="text-sm text-foreground/70">
            Experienced professors with Ph.D. qualifications and industry expertise
          </p>
        </Card>

        <Card className="p-5 text-center bg-transparent border-2 border-primary/50 hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all">
          <div className="flex justify-center mb-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-transparent border-2 border-primary/50">
              <Target className="h-6 w-6 text-primary" />
            </div>
          </div>
          <h3 className="text-base font-semibold mb-2 text-primary">Career Focus</h3>
          <p className="text-sm text-foreground/70">Strong placement support with top MNCs and startups recruiting</p>
        </Card>
      </div>
    </section>
  )
}
