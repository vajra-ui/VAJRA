import { Card, CardContent } from "@/components/ui/card"
import { Eye, Target } from "lucide-react"

export function Vision() {
  return (
    <section className="py-8 md:py-12 lg:py-16 border-y border-primary/20">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 max-w-5xl mx-auto">
        <Card className="border-2 border-primary/30 hover:border-primary bg-card transition-all hover:shadow-lg hover:shadow-primary/20">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center gap-2 md:gap-3 mb-2 md:mb-3">
              <div className="flex h-9 w-9 md:h-10 md:w-10 items-center justify-center rounded-lg bg-primary/20 border border-primary/50">
                <Eye className="h-4 w-4 md:h-5 md:w-5 text-primary" />
              </div>
              <h3 className="text-lg md:text-xl font-bold text-primary">Our Vision</h3>
            </div>
            <p className="text-xs md:text-sm text-foreground/80 leading-relaxed">
              To be a center of excellence in Computer Science and Engineering education, producing innovative
              professionals who contribute to technological advancement and societal development through cutting-edge
              research and industry collaboration.
            </p>
          </CardContent>
        </Card>

        <Card className="border-2 border-primary/30 hover:border-primary bg-card transition-all hover:shadow-lg hover:shadow-primary/20">
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center gap-2 md:gap-3 mb-2 md:mb-3">
              <div className="flex h-9 w-9 md:h-10 md:w-10 items-center justify-center rounded-lg bg-primary/20 border border-primary/50">
                <Target className="h-4 w-4 md:h-5 md:w-5 text-primary" />
              </div>
              <h3 className="text-lg md:text-xl font-bold text-primary">Our Mission</h3>
            </div>
            <ul className="space-y-1.5 md:space-y-2 text-xs md:text-sm text-foreground/80">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Provide quality education with modern curriculum and teaching methods</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Foster research culture and innovation among students and faculty</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>Build strong industry partnerships for placements and internships</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
