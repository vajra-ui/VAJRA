"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Trophy, Medal, Star, Award } from "lucide-react"
import dynamic from "next/dynamic"

const ElectricBorder = dynamic(() => import("@/components/animations/ElectricBorder"), { ssr: false })

export function Achievements() {
  const achievements = [
    {
      title: "NAAC A+ Accreditation",
      description: "Department awarded highest grade for academic excellence",
      icon: Trophy,
    },
    {
      title: "Best Department Award 2024",
      description: "Recognized as the best CSE department in the region",
      icon: Award,
    },
    {
      title: "Smart India Hackathon",
      description: "Multiple teams won prizes in national hackathons",
      icon: Medal,
    },
    {
      title: "Research Excellence",
      description: "Faculty received grants for innovative research projects",
      icon: Star,
    },
  ]

  return (
    <section id="achievements" className="py-12 md:py-16 bg-black border-y border-primary/20">
      <div className="mx-auto max-w-3xl text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-bold text-primary mb-3 text-balance">Achievements & Recognition</h2>
        <p className="text-base text-foreground/70 text-pretty">
          Celebrating our milestones and accomplishments in academics and beyond
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-4 max-w-4xl mx-auto">
        {achievements.map((achievement, index) => {
          const Icon = achievement.icon
          return (
            <ElectricBorder key={index} color="#D4AF37" speed={1} chaos={0.4} thickness={2} style={{ borderRadius: 8 }}>
              <Card className="hover:shadow-lg hover:shadow-primary/20 transition-all bg-black border-0 h-full">
                <CardContent className="p-5">
                  <div className="flex items-start gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/20 border border-primary/50">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-base font-semibold mb-1.5 text-primary">{achievement.title}</h3>
                      <p className="text-sm text-foreground/70">{achievement.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </ElectricBorder>
          )
        })}
      </div>
    </section>
  )
}
