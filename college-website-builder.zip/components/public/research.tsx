import { Card, CardContent } from "@/components/ui/card"
import { FileText, Award, Users } from "lucide-react"

export function Research() {
  return (
    <section id="research" className="py-8 md:py-12 lg:py-16">
      <div className="mx-auto max-w-3xl text-center mb-6 md:mb-8">
        <h2 className="text-xl md:text-2xl lg:text-3xl font-bold text-primary mb-2 md:mb-3 text-balance">
          Research & Innovation
        </h2>
        <p className="text-sm md:text-base text-foreground/70 text-pretty">
          Contributing to the advancement of computer science through cutting-edge research
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4 mb-6 md:mb-8">
        <Card className="text-center bg-transparent border-2 border-primary/50 hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all">
          <CardContent className="p-4 md:p-5">
            <div className="flex justify-center mb-2 md:mb-3">
              <div className="flex h-10 w-10 md:h-12 md:w-12 items-center justify-center rounded-full bg-transparent border-2 border-primary/50">
                <FileText className="h-5 w-5 md:h-6 md:w-6 text-primary" />
              </div>
            </div>
            <h3 className="text-xl md:text-2xl font-bold text-primary mb-1">50+</h3>
            <p className="text-xs md:text-sm text-foreground/70">Research Publications</p>
          </CardContent>
        </Card>

        <Card className="text-center bg-transparent border-2 border-primary/50 hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all">
          <CardContent className="p-4 md:p-5">
            <div className="flex justify-center mb-2 md:mb-3">
              <div className="flex h-10 w-10 md:h-12 md:w-12 items-center justify-center rounded-full bg-transparent border-2 border-primary/50">
                <Award className="h-5 w-5 md:h-6 md:w-6 text-primary" />
              </div>
            </div>
            <h3 className="text-xl md:text-2xl font-bold text-primary mb-1">15+</h3>
            <p className="text-xs md:text-sm text-foreground/70">Patents Filed</p>
          </CardContent>
        </Card>

        <Card className="text-center bg-transparent border-2 border-primary/50 hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all">
          <CardContent className="p-4 md:p-5">
            <div className="flex justify-center mb-2 md:mb-3">
              <div className="flex h-10 w-10 md:h-12 md:w-12 items-center justify-center rounded-full bg-transparent border-2 border-primary/50">
                <Users className="h-5 w-5 md:h-6 md:w-6 text-primary" />
              </div>
            </div>
            <h3 className="text-xl md:text-2xl font-bold text-primary mb-1">10+</h3>
            <p className="text-xs md:text-sm text-foreground/70">Ongoing Projects</p>
          </CardContent>
        </Card>
      </div>

      <div className="max-w-4xl mx-auto">
        <h3 className="text-lg md:text-xl font-bold text-primary mb-4 md:mb-5 text-center">Research Focus Areas</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 md:gap-3">
          {[
            "Artificial Intelligence & Machine Learning",
            "Internet of Things (IoT)",
            "Blockchain Technology",
            "Cloud Computing & Edge Computing",
            "Cybersecurity & Privacy",
            "Data Science & Big Data Analytics",
          ].map((area, index) => (
            <div
              key={index}
              className="flex items-center gap-2 md:gap-3 p-2.5 md:p-3 bg-transparent rounded-lg border-2 border-primary/50 hover:border-primary transition-all"
            >
              <div className="h-1.5 w-1.5 md:h-2 md:w-2 rounded-full bg-primary shrink-0" />
              <span className="text-xs md:text-sm text-foreground/80 font-medium">{area}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
