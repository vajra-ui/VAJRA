import { Card, CardContent } from "@/components/ui/card"
import { MapPin, Phone, Mail, Globe } from "lucide-react"

export function Contact() {
  return (
    <section id="contact" className="py-12 md:py-16 lg:py-20 bg-background/50">
      <div className="container mx-auto px-3 sm:px-4">
        <div className="mx-auto max-w-3xl text-center mb-8 md:mb-12">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-primary mb-3 md:mb-4 text-balance">
            Contact Us
          </h2>
          <p className="text-base md:text-lg text-foreground/70 text-pretty">
            Get in touch with our department for any inquiries
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 max-w-4xl mx-auto">
          <Card className="bg-card border-primary/30 hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all">
            <CardContent className="p-4 md:p-6 space-y-4 md:space-y-6">
              <div className="flex items-start gap-3 md:gap-4">
                <div className="flex h-9 w-9 md:h-10 md:w-10 shrink-0 items-center justify-center rounded-lg bg-primary/20 border border-primary/50">
                  <MapPin className="h-4 w-4 md:h-5 md:w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1 text-primary text-sm md:text-base">Address</h3>
                  <p className="text-xs md:text-sm text-foreground/70">
                    Paavai Engineering College
                    <br />
                    Pachal, Namakkal - 637018
                    <br />
                    Tamil Nadu, India
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 md:gap-4">
                <div className="flex h-9 w-9 md:h-10 md:w-10 shrink-0 items-center justify-center rounded-lg bg-primary/20 border border-primary/50">
                  <Phone className="h-4 w-4 md:h-5 md:w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1 text-primary text-sm md:text-base">Phone</h3>
                  <p className="text-xs md:text-sm text-foreground/70">
                    +91-4288-268411
                    <br />
                    +91-4288-268412
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 md:gap-4">
                <div className="flex h-9 w-9 md:h-10 md:w-10 shrink-0 items-center justify-center rounded-lg bg-primary/20 border border-primary/50">
                  <Mail className="h-4 w-4 md:h-5 md:w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1 text-primary text-sm md:text-base">Email</h3>
                  <p className="text-xs md:text-sm text-foreground/70 break-all">
                    cse@paavai.edu.in
                    <br />
                    info@paavai.edu.in
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 md:gap-4">
                <div className="flex h-9 w-9 md:h-10 md:w-10 shrink-0 items-center justify-center rounded-lg bg-primary/20 border border-primary/50">
                  <Globe className="h-4 w-4 md:h-5 md:w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1 text-primary text-sm md:text-base">Website</h3>
                  <p className="text-xs md:text-sm text-foreground/70 break-all">www.paavai.edu.in</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-primary/30 hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all">
            <CardContent className="p-4 md:p-6">
              <h3 className="text-base md:text-lg font-semibold mb-3 md:mb-4 text-primary">Office Hours</h3>
              <div className="space-y-3 md:space-y-4">
                <div>
                  <p className="font-medium text-foreground text-sm md:text-base">Monday - Friday</p>
                  <p className="text-xs md:text-sm text-foreground/70">9:00 AM - 5:00 PM</p>
                </div>
                <div>
                  <p className="font-medium text-foreground text-sm md:text-base">Saturday</p>
                  <p className="text-xs md:text-sm text-foreground/70">9:00 AM - 1:00 PM</p>
                </div>
                <div>
                  <p className="font-medium text-foreground text-sm md:text-base">Sunday</p>
                  <p className="text-xs md:text-sm text-foreground/70">Closed</p>
                </div>
              </div>

              <div className="mt-4 md:mt-6 p-3 md:p-4 bg-primary/10 border border-primary/30 rounded-lg">
                <p className="text-xs md:text-sm text-foreground/80">
                  <strong className="text-primary">For Admissions:</strong> Visit the college office or contact our
                  admission cell for information about upcoming admissions.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
