"use client"

import { useEffect, useRef, useState } from "react"
import { Card } from "@/components/ui/card"

interface CardData {
  title: string
  description: string
  color: string
}

interface CardSwapProps {
  cards: CardData[]
  autoSwapInterval?: number
}

export function CardSwap({ cards, autoSwapInterval = 5000 }: CardSwapProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const interval = setInterval(() => {
      handleNext()
    }, autoSwapInterval)

    return () => clearInterval(interval)
  }, [currentIndex, autoSwapInterval])

  const handleNext = () => {
    if (isAnimating) return
    setIsAnimating(true)
    setCurrentIndex((prev) => (prev + 1) % cards.length)
    setTimeout(() => setIsAnimating(false), 400)
  }

  const handleCardClick = (index: number) => {
    if (isAnimating || index === currentIndex) return
    setIsAnimating(true)
    setCurrentIndex(index)
    setTimeout(() => setIsAnimating(false), 400)
  }

  const getCardPosition = (index: number) => {
    const diff = index - currentIndex
    const total = cards.length

    if (diff === 0) {
      return {
        zIndex: total,
        transform: "translateX(0) translateY(0) scale(1)",
        opacity: 1,
        pointerEvents: "auto" as const,
      }
    } else if (diff === 1 || diff === -(total - 1)) {
      return {
        zIndex: total - 1,
        transform: "translateX(15%) translateY(5%) scale(0.95)",
        opacity: 0.7,
        pointerEvents: "auto" as const,
      }
    } else if (diff === 2 || diff === -(total - 2)) {
      return {
        zIndex: total - 2,
        transform: "translateX(30%) translateY(10%) scale(0.9)",
        opacity: 0.4,
        pointerEvents: "auto" as const,
      }
    } else {
      return {
        zIndex: 0,
        transform: "translateX(50%) translateY(15%) scale(0.85)",
        opacity: 0,
        pointerEvents: "none" as const,
      }
    }
  }

  return (
    <div className="py-8 md:py-12 lg:py-20 bg-black overflow-hidden">
      <div className="container mx-auto px-3 sm:px-4">
        <div className="mx-auto max-w-3xl text-center mb-8 md:mb-12">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-primary mb-3 md:mb-4 text-balance">
            Department Highlights
          </h2>
          <p className="text-base md:text-lg text-foreground/70 text-pretty">
            Showcasing our achievements and excellence
          </p>
        </div>

        <div ref={containerRef} className="relative h-[300px] sm:h-[350px] md:h-[450px] lg:h-[500px] max-w-4xl mx-auto">
          {cards.map((card, index) => {
            const style = getCardPosition(index)
            return (
              <div
                key={index}
                className="absolute inset-0 transition-all duration-500 ease-out cursor-pointer"
                style={{
                  zIndex: style.zIndex,
                  transform: style.transform,
                  opacity: style.opacity,
                  pointerEvents: style.pointerEvents,
                }}
                onClick={() => handleCardClick(index)}
              >
                <Card className="h-full w-full shadow-2xl overflow-hidden bg-gradient-to-br from-primary/90 to-primary border-2 border-primary">
                  <div className="h-full w-full p-6 sm:p-8 md:p-10 lg:p-12 flex flex-col items-center justify-center text-center text-black border-4 border-primary/30 rounded-lg">
                    <h3 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold mb-3 md:mb-4 text-balance">
                      {card.title}
                    </h3>
                    <p className="text-sm sm:text-base md:text-lg lg:text-xl text-black/90 max-w-2xl text-pretty">
                      {card.description}
                    </p>
                  </div>
                </Card>
              </div>
            )
          })}
        </div>

        <div className="flex justify-center gap-1.5 md:gap-2 mt-6 md:mt-8">
          {cards.map((_, index) => (
            <button
              key={index}
              onClick={() => handleCardClick(index)}
              className={`h-1.5 md:h-2 rounded-full transition-all duration-300 ${
                index === currentIndex ? "w-6 md:w-8 bg-primary" : "w-1.5 md:w-2 bg-foreground/30"
              }`}
              aria-label={`Go to card ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
