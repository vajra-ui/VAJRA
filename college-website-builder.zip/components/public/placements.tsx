"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Building2, TrendingUp, Briefcase } from "lucide-react"
import { useEffect, useState } from "react"
import { createBrowserClient } from "@/lib/supabase/client"

export function Placements() {
  const [placements, setPlacements] = useState<any[]>([])
  const supabase = createBrowserClient()

  useEffect(() => {
    async function fetchPlacements() {
      const { data, error } = await supabase
        .from("placements")
        .select("*")
        .order("placement_date", { ascending: false })
        .limit(10)

      if (error) {
        console.error("[v0] Error fetching placements:", error)
      } else if (data) {
        setPlacements(data)
      }
    }

    fetchPlacements()
  }, [supabase])

  const topRecruiters = [
    "Cognizant",
    "TCS",
    "Infosys",
    "Wipro",
    "Accenture",
    "HCL Technologies",
    "Tech Mahindra",
    "Capgemini",
  ]

  return (
    <section id="placements" className="py-12 md:py-16 lg:py-20 bg-background">
      <div className="container mx-auto px-3 sm:px-4">
        <div className="mx-auto max-w-3xl text-center mb-8 md:mb-12">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-primary mb-3 md:mb-4 text-balance">
            Placements & Career
          </h2>
          <p className="text-base md:text-lg text-foreground/80 text-pretty">
            Outstanding placement record with top companies hiring our graduates
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6 mb-8 md:mb-12">
          <Card className="text-center bg-card border-primary/30">
            <CardContent className="p-4 md:p-6">
              <div className="flex justify-center mb-3 md:mb-4">
                <div className="flex h-12 w-12 md:h-14 md:w-14 items-center justify-center rounded-full golden-gradient">
                  <TrendingUp className="h-6 w-6 md:h-7 md:w-7 text-primary-foreground" />
                </div>
              </div>
              <h3 className="text-2xl md:text-3xl font-bold text-primary mb-1 md:mb-2">Excellent</h3>
              <p className="text-sm md:text-base text-foreground font-medium">Placement Support</p>
            </CardContent>
          </Card>

          <Card className="text-center bg-card border-primary/30">
            <CardContent className="p-4 md:p-6">
              <div className="flex justify-center mb-3 md:mb-4">
                <div className="flex h-12 w-12 md:h-14 md:w-14 items-center justify-center rounded-full golden-gradient">
                  <Briefcase className="h-6 w-6 md:h-7 md:w-7 text-primary-foreground" />
                </div>
              </div>
              <h3 className="text-2xl md:text-3xl font-bold text-primary mb-1 md:mb-2">4.5 LPA</h3>
              <p className="text-sm md:text-base text-foreground font-medium">Average Package</p>
            </CardContent>
          </Card>

          <Card className="text-center bg-card border-primary/30">
            <CardContent className="p-4 md:p-6">
              <div className="flex justify-center mb-3 md:mb-4">
                <div className="flex h-12 w-12 md:h-14 md:w-14 items-center justify-center rounded-full golden-gradient">
                  <Building2 className="h-6 w-6 md:h-7 md:w-7 text-primary-foreground" />
                </div>
              </div>
              <h3 className="text-2xl md:text-3xl font-bold text-primary mb-1 md:mb-2">50+</h3>
              <p className="text-sm md:text-base text-foreground font-medium">Companies Visit</p>
            </CardContent>
          </Card>
        </div>

        <div className="max-w-4xl mx-auto">
          <h3 className="text-xl md:text-2xl font-bold text-primary mb-4 md:mb-6 text-center">Top Recruiters</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 md:gap-4">
            {topRecruiters.map((company, index) => (
              <div
                key={index}
                className="flex items-center justify-center p-3 md:p-4 bg-card rounded-lg border border-primary/30 hover:border-primary hover:shadow-md hover:shadow-primary/20 transition-all"
              >
                <span className="text-xs md:text-sm text-foreground font-semibold text-center">{company}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
