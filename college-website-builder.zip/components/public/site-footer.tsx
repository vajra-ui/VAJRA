import Link from "next/link"
import { Facebook, Twitter, Linkedin, Youtube } from "lucide-react"

export function SiteFooter() {
  return (
    <footer className="bg-background border-t border-primary/20 text-foreground/70">
      <div className="container mx-auto px-3 sm:px-4 md:px-6 py-8 md:py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          <div>
            <h3 className="text-primary font-bold text-base md:text-lg mb-3 md:mb-4">CSE Department</h3>
            <p className="text-xs md:text-sm text-foreground/60">
              Paavai Engineering College, Namakkal. Excellence in Computer Science Education since 2000.
            </p>
          </div>

          <div>
            <h3 className="text-primary font-semibold text-sm md:text-base mb-3 md:mb-4">Quick Links</h3>
            <ul className="space-y-1.5 md:space-y-2 text-xs md:text-sm">
              <li>
                <a href="#about" className="hover:text-primary transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#programs" className="hover:text-primary transition-colors">
                  Programs
                </a>
              </li>
              <li>
                <a href="#faculty" className="hover:text-primary transition-colors">
                  Faculty
                </a>
              </li>
              <li>
                <a href="#placements" className="hover:text-primary transition-colors">
                  Placements
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-primary font-semibold text-sm md:text-base mb-3 md:mb-4">Resources</h3>
            <ul className="space-y-1.5 md:space-y-2 text-xs md:text-sm">
              <li>
                <Link href="/admin/login" className="hover:text-primary transition-colors">
                  Admin Login
                </Link>
              </li>
              <li>
                <a href="#research" className="hover:text-primary transition-colors">
                  Research
                </a>
              </li>
              <li>
                <a href="#achievements" className="hover:text-primary transition-colors">
                  Achievements
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-primary transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-primary font-semibold text-sm md:text-base mb-3 md:mb-4">Connect With Us</h3>
            <div className="flex gap-3 md:gap-4">
              <a href="#" className="hover:text-primary transition-colors" aria-label="Facebook">
                <Facebook className="h-4 w-4 md:h-5 md:w-5" />
              </a>
              <a href="#" className="hover:text-primary transition-colors" aria-label="Twitter">
                <Twitter className="h-4 w-4 md:h-5 md:w-5" />
              </a>
              <a href="#" className="hover:text-primary transition-colors" aria-label="LinkedIn">
                <Linkedin className="h-4 w-4 md:h-5 md:w-5" />
              </a>
              <a href="#" className="hover:text-primary transition-colors" aria-label="YouTube">
                <Youtube className="h-4 w-4 md:h-5 md:w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-primary/20 mt-6 md:mt-8 pt-6 md:pt-8 text-center text-xs md:text-sm text-foreground/60">
          <p>
            &copy; 2025 Department of Computer Science and Engineering, Paavai Engineering College. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
