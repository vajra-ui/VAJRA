"use client"

import { Button } from "@/components/ui/button"
import { GraduationCap, Users, Award } from "lucide-react"
import Link from "next/link"
import dynamic from "next/dynamic"

const ElectricBorder = dynamic(() => import("@/components/animations/ElectricBorder"), { ssr: false })

export function Hero() {
  return (
    <section id="home" className="relative bg-black text-foreground overflow-hidden">
      <div className="absolute inset-0 golden-gradient opacity-20" />
      <div className="container relative z-10 mx-auto px-4 py-16 md:py-24 max-w-7xl">
        <div className="mx-auto max-w-4xl text-center">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4 text-balance text-primary">
            Department of Computer Science and Engineering
          </h1>
          <p className="text-lg md:text-xl text-primary/90 mb-6 text-balance">
            Paavai Engineering College, Namakkal, Tamil Nadu
          </p>
          <p className="text-sm md:text-base text-foreground/80 mb-8 max-w-2xl mx-auto text-pretty">
            Empowering future technologists with cutting-edge education, innovative research, and industry-ready skills
            for excellence in Computer Science and Engineering.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center mb-12">
            <Link href="#about">
              <Button
                size="default"
                variant="outline"
                className="w-full sm:w-auto border-2 border-primary text-primary hover:bg-primary/10 bg-transparent"
              >
                Explore Programs
              </Button>
            </Link>
            <Link href="#contact">
              <Button
                size="default"
                variant="outline"
                className="w-full sm:w-auto border-primary text-primary hover:bg-primary/10 bg-transparent"
              >
                Contact Us
              </Button>
            </Link>
            <Link href="/student">
              <Button
                size="default"
                variant="outline"
                className="w-full sm:w-auto border-2 border-primary text-primary hover:bg-primary/10 bg-transparent"
              >
                Student Portal
              </Button>
            </Link>
            <Link href="/faculty">
              <Button
                size="default"
                variant="outline"
                className="w-full sm:w-auto border-2 border-primary text-primary hover:bg-primary/10 bg-transparent"
              >
                Faculty Portal
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-12">
            <ElectricBorder color="#D4AF37" speed={1} chaos={0.5} thickness={2} style={{ borderRadius: 12 }}>
              <div className="bg-black backdrop-blur-sm rounded-lg p-4 hover:bg-black/90 transition-colors">
                <GraduationCap className="h-8 w-8 mb-3 mx-auto text-primary" />
                <h3 className="text-xl font-bold mb-1 text-primary">500+</h3>
                <p className="text-sm text-foreground/80">Students Enrolled</p>
              </div>
            </ElectricBorder>

            <ElectricBorder color="#D4AF37" speed={1} chaos={0.5} thickness={2} style={{ borderRadius: 12 }}>
              <div className="bg-black backdrop-blur-sm rounded-lg p-4 hover:bg-black/90 transition-colors">
                <Users className="h-8 w-8 mb-3 mx-auto text-primary" />
                <h3 className="text-xl font-bold mb-1 text-primary">25+</h3>
                <p className="text-sm text-foreground/80">Expert Faculty</p>
              </div>
            </ElectricBorder>

            <ElectricBorder color="#D4AF37" speed={1} chaos={0.5} thickness={2} style={{ borderRadius: 12 }}>
              <div className="bg-black backdrop-blur-sm rounded-lg p-4 hover:bg-black/90 transition-colors">
                <Award className="h-8 w-8 mb-3 mx-auto text-primary" />
                <h3 className="text-xl font-bold mb-1 text-primary">100%</h3>
                <p className="text-sm text-foreground/80">Placement Support</p>
              </div>
            </ElectricBorder>
          </div>
        </div>
      </div>
    </section>
  )
}
