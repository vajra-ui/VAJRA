"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, GraduationCap } from "lucide-react"
import dynamic from "next/dynamic"

const ElectricBorder = dynamic(() => import("@/components/animations/ElectricBorder"), { ssr: false })

export function Programs() {
  return (
    <section id="programs" className="py-12 md:py-16 bg-black">
      <div className="mx-auto max-w-3xl text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-bold text-primary mb-3 text-balance">Academic Programs</h2>
        <p className="text-base text-foreground/70 text-pretty">
          Comprehensive programs designed to build strong fundamentals and specialized skills
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        <ElectricBorder color="#D4AF37" speed={1} chaos={0.5} thickness={2} style={{ borderRadius: 12 }}>
          <Card className="hover:shadow-xl hover:shadow-primary/20 transition-all bg-transparent border-0">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 border border-primary/50">
                  <GraduationCap className="h-5 w-5 text-primary" />
                </div>
                <CardTitle className="text-lg text-primary">B.E. Computer Science and Engineering</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-foreground/70 mb-3">
                Four-year undergraduate program covering all aspects of computer science, software engineering, and
                emerging technologies.
              </p>
              <ul className="space-y-1.5 text-sm text-foreground/80">
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                  <span>Duration: 4 Years (8 Semesters)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                  <span>Intake: 120 Students</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                  <span>AICTE Approved, NBA Accredited</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </ElectricBorder>

        <ElectricBorder color="#D4AF37" speed={1} chaos={0.5} thickness={2} style={{ borderRadius: 12 }}>
          <Card className="hover:shadow-xl hover:shadow-primary/20 transition-all bg-transparent border-0">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 border border-primary/50">
                  <BookOpen className="h-5 w-5 text-primary" />
                </div>
                <CardTitle className="text-lg text-primary">M.E. Computer Science and Engineering</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-foreground/70 mb-3">
                Two-year postgraduate program with specialization in advanced computing, AI, and research methodologies.
              </p>
              <ul className="space-y-1.5 text-sm text-foreground/80">
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                  <span>Duration: 2 Years (4 Semesters)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                  <span>Intake: 18 Students</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                  <span>Research-Oriented Curriculum</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </ElectricBorder>
      </div>
    </section>
  )
}
