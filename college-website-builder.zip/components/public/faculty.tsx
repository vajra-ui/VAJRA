"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Mail, Phone } from "lucide-react"
import { useEffect, useState } from "react"
import { createBrowserClient } from "@/lib/supabase/client"

interface FacultyMember {
  id: string
  name: string
  designation: string
  qualification: string
  specialization: string
  email: string
  phone: string
}

export function Faculty() {
  const [facultyMembers, setFacultyMembers] = useState<FacultyMember[]>([])
  const supabase = createBrowserClient()

  useEffect(() => {
    async function fetchFaculty() {
      const { data, error } = await supabase.from("faculty").select("*").order("experience_years", { ascending: false })

      if (error) {
        console.error("[v0] Error fetching faculty:", error)
      } else if (data) {
        setFacultyMembers(data)
      }
    }

    fetchFaculty()
  }, [supabase])

  return (
    <section id="faculty" className="py-12 md:py-16 lg:py-20 bg-card">
      <div className="container mx-auto px-3 sm:px-4">
        <div className="mx-auto max-w-3xl text-center mb-8 md:mb-12">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-primary mb-3 md:mb-4 text-balance">
            Our Faculty
          </h2>
          <p className="text-base md:text-lg text-foreground/80 text-pretty">
            Experienced educators and researchers dedicated to student success
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
          {facultyMembers.map((faculty) => (
            <Card
              key={faculty.id}
              className="bg-background border-primary/30 hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all"
            >
              <CardContent className="p-4 md:p-6">
                <div className="flex h-16 w-16 md:h-20 md:w-20 items-center justify-center rounded-full golden-gradient mx-auto mb-3 md:mb-4 border-2 border-primary">
                  <span className="text-xl md:text-2xl font-bold text-primary-foreground">
                    {faculty.name.charAt(0)}
                  </span>
                </div>
                <h3 className="text-base md:text-lg font-semibold text-center mb-1 text-primary line-clamp-2">
                  {faculty.name}
                </h3>
                <p className="text-xs md:text-sm text-primary/80 text-center mb-2">{faculty.designation}</p>
                <p className="text-[10px] md:text-xs text-foreground/70 text-center mb-1">{faculty.qualification}</p>
                <p className="text-[10px] md:text-xs text-foreground font-medium text-center mb-3 line-clamp-2">
                  {faculty.specialization}
                </p>
                <div className="space-y-2 text-[10px] md:text-xs">
                  <div className="flex items-center gap-2 text-foreground/70">
                    <Mail className="h-3 w-3 shrink-0 text-primary" />
                    <span className="truncate">{faculty.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-foreground/70">
                    <Phone className="h-3 w-3 shrink-0 text-primary" />
                    <span>{faculty.phone}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
