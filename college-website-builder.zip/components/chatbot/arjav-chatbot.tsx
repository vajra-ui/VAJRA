"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MessageCircle, X, Send, Bot } from "lucide-react"
import { generateChatResponse } from "./actions"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

export function ArjavChatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "Hello! I'm Arjav, your virtual assistant for Paavai Engineering College's CSE Department. How can I help you today?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight
    }
  }, [messages])

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const assistantMessageContent = await generateChatResponse(
        messages.map((msg) => ({
          role: msg.role,
          content: msg.content,
        })),
        userMessage.content,
      )

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: assistantMessageContent,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      console.error("[v0] Chatbot error:", error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content:
          "I apologize, but I'm having trouble responding right now. Please try again or contact the department directly at +91-4286-226555.",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <>
      {!isOpen && (
        <Button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-50 h-16 w-16 rounded-full bg-gradient-to-br from-yellow-600 to-yellow-500 shadow-2xl hover:from-yellow-500 hover:to-yellow-400 hover:scale-110 transition-all duration-300 border-2 border-yellow-400"
          size="icon"
        >
          <MessageCircle className="h-7 w-7 text-black" />
          <span className="sr-only">Open Arjav Chatbot</span>
        </Button>
      )}

      {isOpen && (
        <Card className="fixed bottom-6 right-6 z-50 w-full max-w-sm h-[500px] flex flex-col shadow-2xl bg-gradient-to-b from-black to-gray-900 border-2 border-yellow-600/50">
          <div className="flex items-center justify-between p-3 border-b border-yellow-600/30 bg-black">
            <div className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-full bg-gradient-to-br from-yellow-600 to-yellow-500 flex items-center justify-center shadow-lg">
                <Bot className="h-5 w-5 text-black" />
              </div>
              <div>
                <h3 className="font-semibold text-yellow-500 text-sm">Arjav</h3>
                <p className="text-xs text-gray-400">CSE Department</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              className="hover:bg-gray-800 h-8 w-8 text-yellow-500 hover:text-yellow-400"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          <ScrollArea
            className="flex-1 p-3 bg-gradient-to-b from-gray-900 to-black overflow-y-auto"
            ref={scrollAreaRef}
          >
            <div className="space-y-3">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[85%] rounded-lg px-3 py-2 shadow-lg ${
                      message.role === "user"
                        ? "bg-gradient-to-br from-yellow-600 to-yellow-500 text-black"
                        : "bg-gradient-to-br from-gray-800 to-gray-900 text-gray-100 border border-yellow-600/20"
                    }`}
                  >
                    <p className="text-sm leading-relaxed">{message.content}</p>
                    <span className="text-[10px] opacity-60 mt-1 block">
                      {message.timestamp.toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-600/20 rounded-lg px-3 py-2">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 bg-yellow-500 rounded-full animate-bounce" />
                      <span className="w-2 h-2 bg-yellow-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                      <span className="w-2 h-2 bg-yellow-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="p-3 border-t border-yellow-600/30 bg-black">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Ask me anything..."
                className="flex-1 bg-gray-900 border-yellow-600/30 text-gray-100 placeholder:text-gray-500 focus:border-yellow-500 h-9 text-sm"
                disabled={isLoading}
              />
              <Button
                onClick={handleSendMessage}
                disabled={!input.trim() || isLoading}
                size="icon"
                className="bg-gradient-to-br from-yellow-600 to-yellow-500 hover:from-yellow-500 hover:to-yellow-400 text-black h-9 w-9"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-[10px] text-gray-500 mt-2 text-center">Powered by AI • Paavai Engineering College</p>
          </div>
        </Card>
      )}
    </>
  )
}
