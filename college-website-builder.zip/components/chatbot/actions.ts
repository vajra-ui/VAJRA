"use server"

const KNOWLEDGE_BASE = {
  greetings: {
    patterns: ["hi", "hello", "hey", "good morning", "good afternoon", "good evening", "namaste"],
    responses: [
      "Hello! I'm Arjav, your virtual assistant for Paavai Engineering College's CSE Department. How can I help you today?",
      "Hi there! Welcome to Paavai Engineering College CSE Department. What would you like to know?",
      "Greetings! I'm here to help you with information about our CSE department. Feel free to ask me anything!",
    ],
  },
  about: {
    patterns: ["about", "college", "paavai", "institution", "tell me about"],
    responses: [
      "Paavai Engineering College is located in Pachal, Namakkal - 637018, Tamil Nadu. We are part of Paavai Institutions, established with a vision for quality education. Our CSE department focuses on producing skilled professionals through innovation and ethical practices. Contact us at +91-4286-226555 or principal@pec.paavai.edu.in",
    ],
  },
  programs: {
    patterns: ["program", "course", "degree", "b.e", "m.e", "phd", "undergraduate", "postgraduate"],
    responses: [
      "We offer three programs: 1) B.E. Computer Science and Engineering (4 years), 2) M.E. Computer Science and Engineering (2 years), and 3) Ph.D. in Computer Science. All programs are designed to provide comprehensive knowledge in computing and technology.",
    ],
  },
  admission: {
    patterns: ["admission", "apply", "join", "enroll", "counselling", "tnea", "eligibility"],
    responses: [
      "Admissions are conducted through TNEA counselling. Our college code is 2611. For B.E. admission, you need to have passed 12th standard with Physics, Chemistry, and Mathematics. For M.E., you need a B.E./B.Tech degree. For more details, contact us at +91-4286-226555.",
    ],
  },
  placements: {
    patterns: ["placement", "job", "recruit", "company", "package", "salary", "career"],
    responses: [
      "We have an excellent placement record! Top recruiters include Cognizant (4.5 LPA), TCS (3.6 LPA), Infosys (4.0 LPA), Wipro (3.5 LPA), and Accenture (4.5 LPA). Our training and placement cell provides comprehensive career guidance and preparation.",
    ],
  },
  facilities: {
    patterns: ["facility", "lab", "infrastructure", "library", "computer", "internet", "equipment"],
    responses: [
      "Our CSE department has state-of-the-art facilities including modern computer laboratories with the latest hardware and software, high-speed internet connectivity, project development labs, research facilities, and smart classrooms with interactive boards.",
    ],
  },
  faculty: {
    patterns: ["faculty", "professor", "teacher", "staff", "hod", "department head"],
    responses: [
      "Our faculty team consists of highly qualified and experienced professors dedicated to student excellence. We have experts in various domains including AI/ML, Data Science, Cloud Computing, Cyber Security, and Software Engineering. They actively engage in research and industry collaboration.",
    ],
  },
  achievements: {
    patterns: ["achievement", "award", "recognition", "excellence", "accomplishment"],
    responses: [
      "Our students have achieved remarkable success including: Excellence in All India Inter University Power Lifting, 100% Scholarship for Masters in Foreign Universities, NSS volunteers in Republic Day parade, ICTACT Youth Icon awards, and Internshala Award recognition.",
    ],
  },
  events: {
    patterns: ["event", "fest", "symposium", "workshop", "astra", "aura", "sparism", "cultural", "technical"],
    responses: [
      "We organize exciting events throughout the year: ASTRA (cultural extravaganza), AURA (technical symposium with coding competitions), SPARISM (annual day), regular workshops on AI/ML/IoT/Cloud Computing, industry expert sessions, and sports competitions.",
    ],
  },
  research: {
    patterns: ["research", "project", "phd", "publication", "innovation"],
    responses: [
      "Our research focus areas include Machine Learning and AI, Data Science and Big Data Analytics, Cloud Computing and IoT, Cyber Security, and Software Engineering. We encourage students and faculty to engage in cutting-edge research and innovation.",
    ],
  },
  contact: {
    patterns: ["contact", "phone", "email", "address", "location", "reach", "call"],
    responses: [
      "You can reach us at: Address: Pachal, Namakkal - 637018, Tamil Nadu, India | Phone: +91-4286-226555, 226666 | Email: principal@pec.paavai.edu.in | We're happy to help with any queries!",
    ],
  },
  fees: {
    patterns: ["fee", "cost", "tuition", "expense", "price", "amount"],
    responses: [
      "For detailed information about fee structure and payment options, please contact our admission office at +91-4286-226555 or email principal@pec.paavai.edu.in. Fee structures may vary by program and are subject to change annually.",
    ],
  },
  hostel: {
    patterns: ["hostel", "accommodation", "stay", "residence", "dorm"],
    responses: [
      "Paavai Engineering College provides separate hostel facilities for boys and girls with all modern amenities. For hostel admission and fee details, please contact the college administration at +91-4286-226555.",
    ],
  },
}

function findBestMatch(userMessage: string): string {
  const lowerMessage = userMessage.toLowerCase()

  // Check each category for pattern matches
  for (const [category, data] of Object.entries(KNOWLEDGE_BASE)) {
    for (const pattern of data.patterns) {
      if (lowerMessage.includes(pattern)) {
        // Return a random response from the category
        const responses = data.responses
        return responses[Math.floor(Math.random() * responses.length)]
      }
    }
  }

  // Default response if no match found
  return "I'd be happy to help! You can ask me about programs, admissions, placements, facilities, faculty, achievements, events, research, or contact information. What would you like to know?"
}

export async function generateChatResponse(
  previousMessages: { role: "user" | "assistant"; content: string }[],
  currentUserMessage: string,
): Promise<string> {
  // Use pattern matching instead of AI SDK
  return findBestMatch(currentUserMessage)
}
