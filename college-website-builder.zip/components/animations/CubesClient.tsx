"use client"

import dynamic from "next/dynamic"

const Cubes = dynamic(() => import("@/components/animations/Cubes"), { ssr: false })

export default Cubes
