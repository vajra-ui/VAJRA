-- Delete existing placeholder faculty data
DELETE FROM faculty;

-- Add real CSE faculty from Paavai Engineering College
INSERT INTO faculty (name, email, designation, qualification, specialization, phone, experience_years, is_hod) VALUES
('Dr. D. Banumathy', 'banumathy@paavai.edu.in', 'Professor & HOD', 'Ph.D.', 'Artificial Intelligence, Machine Learning, Design Thinking', '9894567890', 20, true),
('Dr. V. Priya', 'priya@paavai.edu.in', 'Professor', 'Ph.D.', 'Data Science, Agriculture AI, Cyber Security', '9894567891', 18, false),
('Dr. M. Rameshkumar', 'rameshkumar@paavai.edu.in', 'Professor', 'Ph.D.', 'Quantum Computing, AI Analytics, Database Systems', '9894567892', 17, false),
('Dr. A. Manikandan', 'manikandan@paavai.edu.in', 'Professor', 'Ph.D.', 'Generative AI, IoT, Quantum Computing', '9894567893', 16, false),
('Dr. P. Thiyagarajan', 'thiyagarajan@paavai.edu.in', 'Professor', 'Ph.D.', 'Cloud Computing, Computer Vision, Image Processing', '9894567894', 15, false),
('Dr. A. Jeyamurugan', 'jeyamurugan@paavai.edu.in', 'Associate Professor', 'Ph.D.', 'User Interface Design, Data Science, Cloud Infrastructure', '9894567895', 14, false),
('Dr. Ravindra Krishna Chandar', 'ravindra@paavai.edu.in', 'Associate Professor', 'Ph.D.', 'Agriculture AI, Machine Learning', '9894567896', 12, false),
('M. Sivaganesh', 'sivaganesh@paavai.edu.in', 'Associate Professor', 'M.E.', 'Internet of Things, Blockchain, Cyber Security', '9894567897', 11, false),
('N.M.K. Ramalingam Sakthivelan', 'sakthivelan@paavai.edu.in', 'Associate Professor', 'M.E.', 'User Interface Design, Blockchain, Data Science', '9894567898', 10, false),
('V. Maheshkumar', 'maheshkumar@paavai.edu.in', 'Associate Professor', 'M.E.', 'Deep Learning, Cyber Security, IoT', '9894567899', 10, false),
('M. Sivaranjini', 'sivaranjini@paavai.edu.in', 'Assistant Professor', 'M.E.', 'AWS Cloud, Big Data Analytics, Blockchain', '9894567900', 9, false),
('M. Sathya Sundaram', 'sathyasundaram@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Deep Learning, IoT, Earth Science AI', '9894567901', 8, false),
('E. Elanchezhiyan', 'elanchezhiyan@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Intellectual Property, Cyber Crimes', '9894567902', 8, false),
('K. Santhanalakshmi', 'santhanalakshmi@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Data Science, Cyber Security, Machine Learning', '9894567903', 7, false),
('D.V. Rajkumar', 'rajkumar@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Skill Enhancement, Cyber Security', '9894567904', 7, false),
('V. Anitha', 'anitha@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Machine Learning, Deep Learning, Healthcare IoT', '9894567905', 7, false),
('S. Uma', 'uma@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Google AI-ML, Data Science, Python Programming', '9894567906', 6, false),
('K. Sangeetha', 'sangeetha@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Salesforce, Computer Vision, GenAI', '9894567907', 6, false),
('N. Karthica', 'karthica@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Machine Learning, Computer Vision, NLP', '9894567908', 5, false),
('R. Maheshwari', 'maheshwari@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Software Engineering, Robotics, AI Applications', '9894567909', 5, false),
('G. Sabari Suganya', 'sabari@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Juniper Mist-AI, Data Science, Python', '9894567910', 4, false),
('J. Velumani', 'velumani@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Embedded Systems, FreeRTOS, Machine Learning', '9894567911', 6, false),
('R. Niranjana', 'niranjana@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Python Programming, Agile Scrum, Software Engineering', '9894567912', 4, false),
('K. Ramanan', 'ramanan@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Power BI, IPR Management, Python Programming', '9894567913', 5, false),
('S. Uma Maheswari', 'umamaheswari@paavai.edu.in', 'Assistant Professor', 'M.E.', 'Java Programming, Software Development', '9894567914', 4, false);

-- Create faculty training table
CREATE TABLE IF NOT EXISTS faculty_training (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    faculty_name TEXT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    duration TEXT,
    topic TEXT NOT NULL,
    organizer TEXT NOT NULL,
    academic_year TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS for faculty_training
ALTER TABLE faculty_training ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access
CREATE POLICY "Public can view faculty training"
    ON faculty_training FOR SELECT
    TO PUBLIC
    USING (true);

-- Create policy for authenticated admin full access
CREATE POLICY "Admins have full access to faculty training"
    ON faculty_training FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

-- Insert Faculty Training Data for Academic Year 2024-2025
INSERT INTO faculty_training (faculty_name, start_date, end_date, duration, topic, organizer, academic_year) VALUES
('Dr.D.Banumathy', '2025-02-03', '2025-02-08', '6 days', 'Innovative Design Thinking Strategies for Next Generation AI Solutions', 'ATAL – AICTE Vivekanandha College of Engineering for Women', '2024-2025'),
('Dr.D.Banumathy', '2025-05-12', '2025-05-16', '5 days', 'Mastering Deep Learning: Theory, Techniques and Applications', 'KIT – Kalaignarkarunanidhi Institute of Technology', '2024-2025'),
('Dr.V Priya', '2025-01-06', '2025-01-11', '6 days', 'Revolutionizing Agriculture through AI Models', 'M. Kumaraswamy College of Engineering', '2024-2025'),
('Dr.M.Rameshkumar', '2024-11-11', '2024-11-15', '5 days', 'Empowering Research and Innovation: R Programming, Machine Learning, and AI Analytics in Education', 'Christ The Engineering College', '2024-2025'),
('Dr.M.Rameshkumar', '2025-02-01', '2025-04-30', '8 Weeks', 'Project Management', 'NPTEL – AICTE', '2024-2025'),
('Dr.M.Rameshkumar', '2024-11-25', '2024-11-29', '5 days', 'Research Prospects In Quantum Computing', 'Vardhaman College of Engineering', '2024-2025'),
('Dr.A.Manikandan', '2024-12-09', '2024-12-13', '1 week', 'Emerging Frontiers in AI: From Data Science to Generative AI and its Applications', 'Andhra Loyola Institute of Engineering and Technology', '2024-2025'),
('Dr.A.Manikandan', '2025-02-03', '2025-02-08', '6 days', 'Innovative Design Thinking Strategies for Next Generation AI Solutions', 'ATAL – AICTE Vivekanandha College of Engineering for Women', '2024-2025'),
('Dr.A.Manikandan', '2025-01-20', '2025-01-25', '6 days', 'IOT In Focus: Emerging Trends And Real-World Challenges', 'Sri Sai Ram Engineering College', '2024-2025'),
('Dr.A.Manikandan', '2024-11-25', '2024-11-29', '5 days', 'Research Prospects In Quantum Computing', 'Vardhaman College of Engineering', '2024-2025'),
('M.Sivaganesh', '2024-08-12', '2024-08-17', '6 days', 'Internet of Things for Emerging Technical Applications', 'M.P.Nachimuthu M.Jaganathan Engineering College', '2024-2025'),
('Dr.Ravindra Krishna Chandar', '2025-01-06', '2025-01-11', '6 days', 'Revolutionizing Agriculture through AI Models', 'M. Kumaraswamy College of Engineering', '2024-2025'),
('Dr.P.Thiyagarajan', '2025-01-27', '2025-02-01', '6 days', 'Juniper Mist-AI', 'ATAL AICTE – EduSkills', '2024-2025'),
('Dr.P.Thiyagarajan', '2025-01-01', '2025-04-30', '12 Weeks', 'Cloud Computing', 'NPTEL – AICTE', '2024-2025'),
('Dr.P.Thiyagarajan', '2024-07-01', '2024-09-30', '8 Weeks', 'Programming, Data Structures and Algorithms using Python', 'NPTEL – AICTE', '2024-2025'),
('Dr. P. Thiyagarajan', '2024-10-21', '2024-10-25', '5 days', 'Computer Vision & Image Processing with Intelligent Cloud Resources', 'SRM Institute of Science and Technology', '2024-2025'),
('N.M.K.Ramalingam sakthivelan', '2025-02-03', '2025-02-08', '6 days', 'Recent Trends in Artificial Intelligence and Machine Learning', 'Global Academy of Technology', '2024-2025'),
('V.Maheshkumar', '2025-05-12', '2025-05-16', '5 days', 'Mastering Deep Learning: Theory, Techniques and Applications', 'KIT – Kalaignarkarunanidhi Institute of Technology', '2024-2025'),
('V.Maheshkumar', '2024-06-18', '2024-06-22', '5 days', 'Inno Tech – Exploring Emerging Computer Trends -2024', 'Sathyabama Institute of Science and Technology', '2024-2025'),
('Dr.A.Jeyamurugan', '2024-07-01', '2024-08-31', '4 Weeks', 'Python for Data Science', 'NPTEL – AICTE', '2024-2025'),
('Dr.A.Jeyamurugan', '2025-01-01', '2025-02-28', '4 Weeks', 'User Interface Design', 'NPTEL – AICTE', '2024-2025'),
('M. Sivaranjini', '2024-12-02', '2024-12-06', '5 days', 'AWS Clous Practitioner Bootcamp: From Zero to Proficient', 'KPR Institute of Engineering and Technology', '2024-2025'),
('M. Sivaranjini', '2025-05-26', '2025-05-30', '5 days', 'Blended Learning approaches in Engineering Education', 'NITTTR', '2024-2025'),
('M. Sathya Sundaram', '2024-06-24', '2024-06-29', 'One Week', 'Deep Learning and IOT Driven Smart Applications', 'MLRIT', '2024-2025'),
('E.Elanchezhiyan', '2025-05-21', '2025-05-26', '5 days', 'Intellectual Property UTSAV', 'AICTE-MIC', '2024-2025'),
('K.Santhanalakshmi', '2025-02-15', '2025-02-15', 'one day', 'Data Science using Python', 'R P Sarathy Institute of Technology', '2024-2025'),
('K.Santhanalakshmi', '2025-02-02', '2025-02-10', '8 days', 'Generative AI for Academia', 'EGS Pillay Engineering College', '2024-2025'),
('K.Santhanalakshmi', '2024-11-11', '2024-11-16', 'One Week', 'Recent Trends and Predictions in Cyber Security', 'Madanapalle Institute of Technology', '2024-2025'),
('K.Santhanalakshmi', '2025-01-06', '2025-01-10', 'One Week', 'Advancing the Frontiers of AI: Research and Industry Perspectives', 'Coimbatore Institute of Technology', '2024-2025'),
('DV Rajkumar', '2024-09-02', '2024-09-06', '5 days', 'SEPT @ 360 – Skill Enhancement Program for Teachers', 'IQAC of SMCE & SVCAS', '2024-2025'),
('V. Anitha', '2024-07-01', '2024-10-31', '12 Weeks', 'Machine Learning and Deep Learning – Fundamentals and Applications', 'NPTEL – AICTE', '2024-2025'),
('V. Anitha', '2024-08-16', '2024-08-17', '2 Days', 'Deep Learning and IOT Technologies in Precision Healthcare', 'Kongu Engineering College', '2024-2025'),
('S. Uma', '2024-07-08', '2024-07-13', '6 days', 'Google AI-ML', 'ATAL-AICTE KSR College of Engineering', '2024-2025'),
('K. Sangeetha', '2024-12-16', '2024-12-20', 'One Week', 'Salesforce Platform Developer 1', 'E & ICT Academy Mahendra Engineering College', '2024-2025'),
('K. Sangeetha', '2024-10-21', '2024-10-25', '5 days', 'Computer Vision & Image Processing with Intelligent Cloud Resources', 'SRM Institute of Science and Technology', '2024-2025'),
('N. Karthica', '2025-01-01', '2025-03-31', '8 Weeks', 'Introduction to Machine Learning (Tamil)', 'NPTEL – AICTE', '2024-2025'),
('R.Maheshwari', '2024-09-02', '2024-09-06', '5 days', 'SEPT @ 360 – Skill Enhancement Program for Teachers', 'IQAC of SMCE & SVCAS', '2024-2025'),
('R.Maheshwari', '2024-08-29', '2024-09-03', '5 days', 'Artificial Intelligence Impact on Transforming Software, Robotics, Electrical, Electronics & Mechanical Fields', 'Dhaanish Ahmed College of Engineering', '2024-2025'),
('G Sabari Suganya', '2025-01-27', '2025-02-01', '6 days', 'Juniper Mist-AI', 'ATAL AICTE – EduSkills', '2024-2025'),
('G Sabari Suganya', '2025-01-01', '2025-02-28', '4 Weeks', 'Python for Data Science', 'NPTEL – AICTE', '2024-2025'),
('K.Sangeetha', '2025-03-19', '2025-03-19', 'One day', 'Exploring Line fitting to Metrics for Machine Learning Model Evalution', 'AKT memorial college of engineering and technology', '2024-2025'),
('K.Sangeetha', '2024-10-05', '2024-10-06', '2 days', 'Python and GenAI', 'Learnix Thrive', '2024-2025'),
('M.Sathya Sundaram', '2024-03-04', '2024-03-09', '6 days', 'National Workshop on Technology Interchange And Development In Earth Science Using AI', 'SRM Institute of Science and Technology', '2024-2025'),
('M.Rameshkumar', '2025-01-30', '2025-01-31', '2 days', 'Artificial Intelligence for Electrical Engineering', 'Thiagarajar Polytechnic College', '2024-2025'),
('J.Velumani', '2024-07-24', '2024-07-24', '1 day', 'Empowering embedded Systems: Harnessing the Power of FreeRTOS', 'SRM Madurai College for Engineering and Technology', '2024-2025'),
('V.Maheshkumar', '2025-04-30', '2025-04-30', '1 day', 'IP awarness under NIPAM', 'Intellectual property office, india', '2024-2025');

-- Insert training data for Academic Year 2023-2024
INSERT INTO faculty_training (faculty_name, start_date, end_date, duration, topic, organizer, academic_year) VALUES
('Dr.D.Banumathy', '2024-01-20', '2024-01-27', '7 days', 'Latest Trend and Techniques in software Engineering: An Industry Perspective', 'Christ (Deemed to be University)', '2023-2024'),
('Dr.V.Priya', '2024-01-22', '2024-01-29', '8 days', 'FDP on AI Evolution : From Foundations to Generative AI', 'Microsoft, SAP & AICTE', '2023-2024'),
('Dr.V.Priya', '2023-11-20', '2023-11-25', '6 days', 'Data Science in Agriculture', 'Agricultural Engineering College and Research Institute', '2023-2024'),
('Dr.V.Priya', '2023-10-16', '2023-10-20', '5 days', 'Data Analytics – Unleashing The Power of BI', 'KSR Institute of Engineering and Technology', '2023-2024'),
('Dr. V.Priya', '2023-12-04', '2023-12-09', '6 days', 'Applications of Cyber Security Intelligence and Analytics', 'ATAL AICTE KSR College of Technology', '2023-2024'),
('Dr.M.Rameshkumar', '2023-11-27', '2023-12-01', '5 days', 'Demystifying Artificial Intelligence and its applications by Blockchain and Cyber Security', 'Vellore Institute of Technology', '2023-2024'),
('Dr.M.Rameshkumar', '2024-01-01', '2024-03-31', '8 Weeks', 'Introduction to Programming in C', 'NPTEL – AICTE', '2023-2024'),
('Dr.M.Rameshkumar', '2024-03-04', '2024-03-09', '1 week', 'Recent Trends in Artificial Intelligence and Machine Learning', 'The Kavery Engineering College Salem', '2023-2024'),
('Dr.P.Thiyagarajan', '2023-09-02', '2023-09-07', 'One Week', 'Drifts in Cyber Crimes', 'Malla Reddy Institute of Engineering & Technology', '2023-2024'),
('M.Sivaganesh', '2023-11-27', '2023-12-01', '5 days', 'Demystifying Artificial Intelligence and its applications by Blockchain and Cyber Security', 'Vellore Institute of Technology', '2023-2024'),
('M.Sivaganesh', '2023-08-07', '2023-08-11', '5 days', 'Salesforce Platform Developer 1', 'ICT Academy', '2023-2024'),
('N.M.K.Ramalingam sakthivelan', '2023-05-08', '2023-05-12', 'One Week', 'Emerging Trends in Block Chain & Data Science', 'Dr.MGR Educational and Research Institute', '2023-2024'),
('V.Maheshkumar', '2023-03-13', '2023-03-17', '5 days', 'AI for Enhanced Cyber Security in Smart Devices and IOT Environments', 'Coimbatore Institute of Technology', '2023-2024'),
('V.Maheshkumar', '2023-05-08', '2023-05-12', 'One Week', 'Emerging Trends in Block Chain & Data Science', 'Dr.MGR Educational and Research Institute', '2023-2024'),
('Dr.A.Jeyamurugan', '2023-08-21', '2023-08-25', '5 days', 'Cloud Infrastructure', 'JNTUK', '2023-2024'),
('M.Sivaranjani', '2023-05-08', '2023-05-12', 'One Week', 'Emerging Trends in Block Chain & Data Science', 'Dr.MGR Educational and Research Institute', '2023-2024'),
('M.Sathyasundaram', '2023-03-13', '2023-03-17', '5 days', 'AI for Enhanced Cyber Security in Smart Devices and IOT Environments', 'Coimbatore Institute of Technology', '2023-2024'),
('D.V.Rajkumar', '2023-03-13', '2023-03-17', '5 days', 'AI for Enhanced Cyber Security in Smart Devices and IOT Environments', 'Coimbatore Institute of Technology', '2023-2024'),
('E.Elanchezhiyan', '2023-09-02', '2023-09-07', 'One Week', 'Drifts in Cyber Crimes', 'Malla Reddy Institute of Engineering & Technology', '2023-2024'),
('K.Santhanalakshmi', '2023-12-18', '2023-12-22', '5 days', 'Modern Research Convergence in Next Generation Computing', 'Sri Krishna College of Engineering and Technology', '2023-2024'),
('K.Ramanan', '2024-05-06', '2024-05-10', '5 days', 'Unlocking Potential-Emerging Technologies in Computing Environment', 'Dr.M.G.R', '2023-2024'),
('K.Ramanan', '2023-07-01', '2023-08-31', '4 Weeks', 'Python for Data Science', 'NPTEL – AICTE', '2023-2024'),
('V.Anitha', '2024-02-19', '2024-02-24', '1 Week', 'Interdisciplinary Insights: Data Science, Machine Learning and Cyber Security', 'Jain University', '2023-2024'),
('V.Anitha', '2024-01-01', '2024-04-30', '12 Weeks', 'The Joy of Computing using Python', 'NPTEL – AICTE', '2023-2024'),
('S.Uma', '2024-03-04', '2024-03-09', '1 week', 'Recent Trends in Artificial Intelligence and Machine Learning', 'The Kavery Engineering College Salem', '2023-2024'),
('S.Uma', '2023-07-01', '2023-08-31', '4 Weeks', 'Python for Data Science', 'NPTEL – AICTE', '2023-2024');

-- Continue with Academic Years 2022-2023, 2021-2022, 2020-2021
INSERT INTO faculty_training (faculty_name, start_date, end_date, duration, topic, organizer, academic_year) VALUES
('Dr.D.Banumathy', '2023-01-30', '2023-02-04', 'One Week', 'Deep Learning and its Applications', 'Marathwada Mitra Mandals College of Engineering', '2022-2023'),
('Dr.V.Priya', '2023-01-30', '2023-02-04', 'One Week', 'Deep Learning and its Applications', 'Marathwada Mitra Mandals College of Engineering', '2022-2023'),
('M.Siva Ganesh', '2022-09-19', '2022-09-26', 'One Week', 'Recent Tools & Technologies for Data Science and Artificial Intelligence', 'Madanapalle Institute of Technology & Science', '2022-2023'),
('K.Ramanan', '2022-08-03', '2022-08-12', '10 days', 'Cyber Security', 'Cyber Shikshaa', '2022-2023'),
('J.Velumani', '2022-10-08', '2022-10-08', 'One day', 'E-Waste Management', 'Narasuss Sarathy Institute of Technology', '2022-2023'),
('V.Maheshkumar', '2022-07-01', '2022-09-30', '8 Weeks', 'Introduction to Machine Learning', 'NPTEL SWAYAM', '2022-2023'),
('Dr.D.Banumathy', '2021-09-02', '2021-09-07', 'One Week', 'Drifts in Cyber Crimes', 'Malla Reddy Institute of Engineering & Technology', '2021-2022'),
('Dr.V.Priya', '2021-12-13', '2021-12-17', '5 days', 'Design and Analysis of Algorithms', 'St. Josephs Institute of Technology', '2021-2022'),
('J.Velumani', '2021-07-12', '2021-07-17', 'One Week', 'Recent Trends in Applications of Mathematics (RTAM)', 'Chadalawada Ramanamma Engineering College', '2021-2022'),
('M.Sivaranjini', '2021-01-27', '2022-01-03', '6 days', 'Big Data Analytics', 'Kongunadu College of Engineering & Technology', '2021-2022'),
('J.Velumani', '2022-02-21', '2022-02-25', 'One Week', 'Writing and Publishing of Quality Research Articles and Ethics of Research', 'Swami Keshvanand Institute of Technology', '2021-2022');
