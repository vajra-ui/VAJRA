-- Enable Row Level Security on all tables
ALTER TABLE faculty ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE timetable ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE assignment_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE certificates ENABLE ROW LEVEL SECURITY;
ALTER TABLE research_publications ENABLE ROW LEVEL SECURITY;
ALTER TABLE placements ENABLE ROW LEVEL SECURITY;
ALTER TABLE website_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Public read access for website content
CREATE POLICY "Allow public read access to faculty" ON faculty FOR SELECT USING (true);
CREATE POLICY "Allow public read access to events" ON events FOR SELECT USING (true);
CREATE POLICY "Allow public read access to achievements" ON achievements FOR SELECT USING (true);
CREATE POLICY "Allow public read access to research" ON research_publications FOR SELECT USING (true);
CREATE POLICY "Allow public read access to website content" ON website_content FOR SELECT USING (is_active = true);
CREATE POLICY "Allow public read access to announcements" ON announcements FOR SELECT USING (is_active = true);
CREATE POLICY "Allow public read access to courses" ON courses FOR SELECT USING (true);

-- Admin full access (requires authenticated user with admin metadata)
CREATE POLICY "Allow admin full access to faculty" ON faculty FOR ALL USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Allow admin full access to students" ON students FOR ALL USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Allow admin full access to timetable" ON timetable FOR ALL USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Allow admin full access to attendance" ON attendance FOR ALL USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Allow admin full access to assignments" ON assignments FOR ALL USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Allow admin full access to submissions" ON assignment_submissions FOR ALL USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Allow admin full access to events" ON events FOR ALL USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Allow admin full access to achievements" ON achievements FOR ALL USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Allow admin full access to certificates" ON certificates FOR ALL USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Allow admin full access to research" ON research_publications FOR ALL USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Allow admin full access to placements" ON placements FOR ALL USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Allow admin full access to website content" ON website_content FOR ALL USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Allow admin full access to announcements" ON announcements FOR ALL USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Allow admin read access to admin users" ON admin_users FOR SELECT USING (
  auth.jwt() ->> 'role' = 'authenticated' AND 
  (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);
