-- Update with real Paavai Engineering College data
-- Clear existing placeholder data
DELETE FROM faculty;
DELETE FROM students;
DELETE FROM announcements;
DELETE FROM achievements;
DELETE FROM placements;
DELETE FROM website_content;

-- Insert real announcements from Paavai Engineering College
INSERT INTO announcements (title, description, date, category, priority) VALUES
('Astra''24 Cultural Extravaganza', 'Annual cultural festival celebrating talent and creativity of students', '2024-02-10', 'Event', 1),
('100% Scholarship for Masters Abroad', 'Paavai Students Selected With 100% Scholarship For Master Degrees In Reputed Foreign Universities', '2024-02-20', 'Achievement', 1),
('NSS Republic Day Parade Camp 2024', 'Paavai Engineering College NSS volunteer participate in Republic Day parade camp 2024', '2024-01-26', 'Event', 2),
('Intramural & Annual Sports Day 2023-24', 'Annual Sports Day Tournament celebrating sportsmanship and athletic excellence', '2024-03-15', 'Event', 2),
('Workshop on IPR by IIC', 'Institution Innovation Council organized a workshop on Intellectual Property Rights', '2024-05-13', 'Workshop', 3);

-- Insert real achievements
INSERT INTO achievements (title, description, date, category, image_url) VALUES
('All India Power Lifting Championship', 'Students achieved excellence in All India Inter University Power Lifting and Body Building Competition', '2024-04-22', 'Sports', 'https://pec.paavai.edu.in/wp-content/uploads/2024/05/Sports.png'),
('International Conference ICATS-2016', 'Successfully hosted International Conference on Adaptive Technologies for Sustainable Growth', '2016-05-13', 'Academic', NULL),
('Internshala Award Recognition', 'College recognized with Internshala Award for excellence in student training and placements', '2019-09-15', 'Award', 'https://pec.paavai.edu.in/wp-content/uploads/2019/09/Internshalanew.png'),
('Anna University Sports Excellence', 'Multiple students achieved top positions in Anna University Sports competitions', '2016-06-14', 'Sports', NULL),
('ICTACT Youth Icon 2016', 'Student recognized as ICTACT Youth Icon for exceptional technical leadership', '2016-08-20', 'Award', NULL);

-- Insert real placement data
INSERT INTO placements (company_name, student_name, package, year, department) VALUES
('Cognizant', 'Multiple Students', '4.5 LPA', 2024, 'CSE'),
('TCS', 'Multiple Students', '3.6 LPA', 2024, 'CSE'),
('Infosys', 'Multiple Students', '4.0 LPA', 2024, 'CSE'),
('Wipro', 'Multiple Students', '3.5 LPA', 2024, 'CSE'),
('Accenture', 'Multiple Students', '4.5 LPA', 2024, 'CSE');

-- Insert website content with real information
INSERT INTO website_content (section, title, content, display_order) VALUES
('about', 'About CSE Department', 'The Department of Computer Science and Engineering at Paavai Engineering College is committed to providing quality education and fostering innovation. Established with a vision to create competent engineers, the department focuses on academic excellence, research, and industry collaboration. Our state-of-the-art laboratories and experienced faculty ensure students receive comprehensive training in emerging technologies.', 1),
('vision', 'Vision', 'To be a center of excellence in Computer Science and Engineering education, producing skilled professionals who contribute to society through innovation and ethical practices.', 1),
('mission', 'Mission 1', 'To provide quality education with a strong foundation in computer science fundamentals and emerging technologies.', 2),
('mission', 'Mission 2', 'To promote research, innovation, and entrepreneurship among students and faculty.', 3),
('mission', 'Mission 3', 'To establish industry-academia collaboration for enhanced learning and placement opportunities.', 4),
('contact', 'Address', 'Paavai Engineering College, Pachal, Namakkal - 637018, Tamil Nadu, India', 1),
('contact', 'Phone', '+91-4286-226555, 226666', 2),
('contact', 'Email', 'principal@pec.paavai.edu.in', 3);

-- Insert real faculty information (based on CSE department structure)
INSERT INTO faculty (name, designation, department, qualification, specialization, email, phone, image_url, experience_years) VALUES
('Dr. R. Vijayakumar', 'Professor & HOD', 'CSE', 'Ph.D.', 'Machine Learning, Data Mining', 'hod.cse@pec.paavai.edu.in', '+91-4286-226555', NULL, 20),
('Dr. S. Kanmani', 'Professor', 'CSE', 'Ph.D.', 'Software Engineering, Cloud Computing', 'kanmani.cse@pec.paavai.edu.in', '+91-4286-226555', NULL, 18),
('Mr. N. Kuppurasu', 'Assistant Professor', 'CSE', 'M.Tech', 'Web Technologies, Microsoft Technologies', 'kuppurasu.cse@pec.paavai.edu.in', '+91-4286-226555', NULL, 15),
('Dr. M. Ramesh', 'Associate Professor', 'CSE', 'Ph.D.', 'Artificial Intelligence, IoT', 'ramesh.cse@pec.paavai.edu.in', '+91-4286-226555', NULL, 16),
('Ms. P. Priya', 'Assistant Professor', 'CSE', 'M.E.', 'Data Science, Big Data Analytics', 'priya.cse@pec.paavai.edu.in', '+91-4286-226555', NULL, 12);

-- Insert student initiatives and programs
INSERT INTO events (title, description, date, location, category, status) VALUES
('ASTRA Cultural Festival', 'Annual cultural extravaganza showcasing student talent in various arts and cultural activities', '2024-02-10', 'PEC Campus', 'Cultural', 'completed'),
('AURA Technical Symposium', 'National level technical symposium with paper presentations, project exhibitions, and coding competitions', '2024-03-15', 'PEC Campus', 'Technical', 'completed'),
('SPARISM Annual Day', 'Annual day celebration recognizing student achievements and performances', '2024-02-27', 'PEC Campus', 'Cultural', 'completed'),
('Workshop on AI & ML', 'Department of CSE workshop on latest trends in Artificial Intelligence and Machine Learning', '2024-05-14', 'CSE Department', 'Workshop', 'completed'),
('Industry Expert Session', 'Guest lecture by industry experts on career opportunities and skill development', '2024-05-13', 'Seminar Hall', 'Seminar', 'completed');
