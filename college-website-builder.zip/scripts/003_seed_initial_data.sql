-- Insert sample faculty data
INSERT INTO faculty (name, email, designation, qualification, specialization, phone, experience_years, is_hod) VALUES
('Dr. Rajesh Kumar', 'rajesh.kumar@paavai.edu.in', 'Professor & HOD', 'Ph.D. in Computer Science', 'Artificial Intelligence', '+91-9876543210', 15, true),
('Dr. Priya Sharma', 'priya.sharma@paavai.edu.in', 'Associate Professor', 'Ph.D. in Data Science', 'Machine Learning', '+91-9876543211', 12, false),
('Mr. Arjun Patel', 'arjun.patel@paavai.edu.in', 'Assistant Professor', 'M.Tech in CSE', 'Cloud Computing', '+91-9876543212', 8, false),
('Ms. Lakshmi Narayanan', 'lakshmi.n@paavai.edu.in', 'Assistant Professor', 'M.Tech in CSE', 'Cybersecurity', '+91-9876543213', 6, false);

-- Insert sample courses
INSERT INTO courses (code, name, credits, year, semester, description) VALUES
('CS101', 'Programming in C', 4, 1, 1, 'Introduction to programming using C language'),
('CS201', 'Data Structures', 4, 2, 1, 'Fundamental data structures and algorithms'),
('CS301', 'Database Management Systems', 4, 3, 1, 'Relational databases, SQL, and database design'),
('CS401', 'Machine Learning', 4, 4, 1, 'Introduction to machine learning algorithms and applications');

-- Insert sample website content for CardSwap
INSERT INTO website_content (section, title, description, display_order, is_active) VALUES
('highlights', 'NAAC A+ Accredited', 'Department accredited with highest grade for academic excellence', 1, true),
('highlights', '100% Placement Record', 'All eligible students placed in top MNCs and startups', 2, true),
('highlights', 'Research Excellence', 'Over 50 research papers published in reputed journals', 3, true),
('highlights', 'State-of-art Labs', 'Modern labs with latest technology and software', 4, true);

-- Insert sample events
INSERT INTO events (title, description, event_date, venue, category) VALUES
('TechFest 2025', 'Annual technical symposium with coding competitions and workshops', '2025-02-15 09:00:00+00', 'College Auditorium', 'Technical'),
('Industry Expert Talk', 'Session on AI trends by Google Engineer', '2025-01-20 14:00:00+00', 'Seminar Hall', 'Seminar');

-- Insert sample announcements
INSERT INTO announcements (title, content, priority, is_active) VALUES
('Semester Registration Open', 'Registration for Spring 2025 semester is now open. Last date: Jan 31, 2025', 'high', true),
('Workshop on Cloud Computing', 'Free workshop for final year students. Register before Jan 25', 'normal', true);
