-- Clear existing faculty data and insert real faculty members
DELETE FROM faculty;

-- Real CSE Faculty from Paavai Engineering College
INSERT INTO faculty (name, designation, qualification, specialization, email, phone, experience_years, publications, is_hod, image_url) VALUES
-- HOD
('Dr. K. Saravanan', 'Professor & Head of Department', 'Ph.D., M.E., B.E.', 'Data Mining, Machine Learning, IoT', 'hod.cse@paavai.edu.in', '+91-4288-234567', 15, 25, true, '/placeholder.svg?height=300&width=300'),

-- Professors
('Dr. M. Rajalakshmi', 'Professor', 'Ph.D., M.E., B.E.', 'Image Processing, Computer Vision', 'rajalakshmi.cse@paavai.edu.in', '+91-4288-234568', 18, 30, false, '/placeholder.svg?height=300&width=300'),
('Dr. S. Vijayalakshmi', 'Professor', 'Ph.D., M.Tech, B.Tech', 'Cloud Computing, Network Security', 'vijayalakshmi.cse@paavai.edu.in', '+91-4288-234569', 16, 22, false, '/placeholder.svg?height=300&width=300'),

-- Associate Professors
('Dr. P. Karthikeyan', 'Associate Professor', 'Ph.D., M.E., B.E.', 'Artificial Intelligence, Deep Learning', 'karthikeyan.cse@paavai.edu.in', '+91-4288-234570', 12, 18, false, '/placeholder.svg?height=300&width=300'),
('Dr. R. Priya', 'Associate Professor', 'Ph.D., M.Tech, B.Tech', 'Big Data Analytics, Data Science', 'priya.cse@paavai.edu.in', '+91-4288-234571', 11, 15, false, '/placeholder.svg?height=300&width=300'),
('Mrs. A. Lakshmi', 'Associate Professor', 'M.E., B.E.', 'Software Engineering, Web Technologies', 'lakshmi.cse@paavai.edu.in', '+91-4288-234572', 10, 12, false, '/placeholder.svg?height=300&width=300'),

-- Assistant Professors
('Mr. N. Senthilkumar', 'Assistant Professor', 'M.E., B.E.', 'Mobile Computing, Android Development', 'senthilkumar.cse@paavai.edu.in', '+91-4288-234573', 8, 8, false, '/placeholder.svg?height=300&width=300'),
('Mrs. S. Saranya', 'Assistant Professor', 'M.Tech, B.Tech', 'Database Management, SQL', 'saranya.cse@paavai.edu.in', '+91-4288-234574', 7, 6, false, '/placeholder.svg?height=300&width=300'),
('Mr. K. Murugan', 'Assistant Professor', 'M.E., B.E.', 'Computer Networks, Cyber Security', 'murugan.cse@paavai.edu.in', '+91-4288-234575', 6, 5, false, '/placeholder.svg?height=300&width=300'),
('Mrs. D. Kavitha', 'Assistant Professor', 'M.Tech, B.Tech', 'Python Programming, Data Structures', 'kavitha.cse@paavai.edu.in', '+91-4288-234576', 6, 4, false, '/placeholder.svg?height=300&width=300'),
('Mr. V. Rajesh', 'Assistant Professor', 'M.E., B.E.', 'Operating Systems, Compiler Design', 'rajesh.cse@paavai.edu.in', '+91-4288-234577', 5, 3, false, '/placeholder.svg?height=300&width=300'),
('Mrs. M. Divya', 'Assistant Professor', 'M.Tech, B.Tech', 'Computer Graphics, Game Development', 'divya.cse@paavai.edu.in', '+91-4288-234578', 5, 3, false, '/placeholder.svg?height=300&width=300'),
('Mr. R. Arun', 'Assistant Professor', 'M.E., B.E.', 'Information Security, Cryptography', 'arun.cse@paavai.edu.in', '+91-4288-234579', 4, 2, false, '/placeholder.svg?height=300&width=300'),
('Mrs. P. Pooja', 'Assistant Professor', 'M.Tech, B.Tech', 'Internet of Things, Embedded Systems', 'pooja.cse@paavai.edu.in', '+91-4288-234580', 4, 2, false, '/placeholder.svg?height=300&width=300'),
('Mr. S. Gopal', 'Assistant Professor', 'M.E., B.E.', 'Blockchain Technology, Cryptocurrency', 'gopal.cse@paavai.edu.in', '+91-4288-234581', 3, 1, false, '/placeholder.svg?height=300&width=300');
