import { Hero } from "@/components/public/hero"
import { About } from "@/components/public/about"
import { Vision } from "@/components/public/vision"
import { CardSwap } from "@/components/public/card-swap"
import { Programs } from "@/components/public/programs"
import { Faculty } from "@/components/public/faculty"
import { Labs } from "@/components/public/labs"
import { Research } from "@/components/public/research"
import { Placements } from "@/components/public/placements"
import { Achievements } from "@/components/public/achievements"
import { Contact } from "@/components/public/contact"
import { SiteHeader } from "@/components/public/site-header"
import { SiteFooter } from "@/components/public/site-footer"
import { ArjavChatbot } from "@/components/chatbot/arjav-chatbot"
import Cubes from "@/components/animations/CubesClient"

export default function HomePage() {
  const highlightCards = [
    {
      title: "100% Scholarship Abroad",
      description: "Paavai students selected with 100% scholarship for Master degrees in reputed foreign universities",
      color: "golden",
    },
    {
      title: "ASTRA Cultural Festival",
      description: "Annual cultural extravaganza showcasing student talent in arts, music, and dance",
      color: "golden",
    },
    {
      title: "AURA Tech Symposium",
      description:
        "National level technical symposium with paper presentations, coding competitions, and project exhibitions",
      color: "golden",
    },
    {
      title: "Sports Excellence",
      description: "All India Inter University Power Lifting and Body Building champions",
      color: "golden",
    },
    {
      title: "Internshala Award",
      description: "College recognized with Internshala Award for excellence in student training and placements",
      color: "golden",
    },
  ]

  return (
    <div className="flex min-h-screen flex-col bg-black">
      <SiteHeader />
      <main className="flex-1">
        <Hero />
        <section className="py-8 md:py-12 lg:py-16 bg-background relative overflow-hidden">
          <div className="absolute inset-0 golden-gradient opacity-10" />
          <div className="container mx-auto px-4 max-w-7xl relative z-10">
            <div className="mx-auto max-w-3xl text-center mb-6 md:mb-8">
              <h2 className="text-xl md:text-2xl lg:text-3xl font-bold text-primary mb-2 md:mb-3 text-balance">
                Interactive Experience
              </h2>
              <p className="text-sm md:text-base text-foreground/70 text-pretty">
                Move your cursor over the cubes to interact with our dynamic 3D grid
              </p>
            </div>
            <div className="flex justify-center items-center">
              <div className="w-full max-w-[280px] sm:max-w-[320px] md:max-w-[400px] aspect-square">
                <Cubes
                  gridSize={6}
                  maxAngle={50}
                  radius={3}
                  borderStyle="1px solid #D4AF37"
                  faceColor="#0a0a0a"
                  rippleColor="#D4AF37"
                  rippleSpeed={1.5}
                  autoAnimate={true}
                  rippleOnClick={true}
                  shadow="0 0 15px rgba(212, 175, 55, 0.2)"
                />
              </div>
            </div>
          </div>
        </section>
        <div className="container mx-auto max-w-7xl px-3 sm:px-4 md:px-6 lg:px-8">
          <About />
          <Vision />
          <CardSwap cards={highlightCards} autoSwapInterval={5000} />
          <Programs />
          <Faculty />
          <Labs />
          <Research />
          <Placements />
          <Achievements />
          <Contact />
        </div>
      </main>
      <SiteFooter />
      <ArjavChatbot />
    </div>
  )
}
