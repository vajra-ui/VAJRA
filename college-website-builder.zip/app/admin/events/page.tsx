import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { AdminHeader } from "@/components/admin/admin-header"
import { EventsManager } from "@/components/admin/events-manager"

export default async function EventsPage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user || !data.user.user_metadata?.is_admin) {
    redirect("/admin/login")
  }

  const { data: events } = await supabase.from("events").select("*").order("event_date", { ascending: false })

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader />
      <main className="container mx-auto p-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Events Management</h1>
          <p className="text-gray-600 mt-1">Schedule and manage department events</p>
        </div>
        <EventsManager events={events || []} />
      </main>
    </div>
  )
}
