"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useRouter } from "next/navigation"
import { useState } from "react"
import { Shield } from "lucide-react"

export default function AdminLoginPage() {
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    console.log("[v0] Admin login attempt with password:", password)

    if (password !== "VAJRA123") {
      setError("Invalid password. Access denied.")
      setIsLoading(false)
      console.log("[v0] Password validation failed")
      return
    }

    try {
      console.log("[v0] Password validated successfully, setting session")

      // Store admin session in localStorage for this demo
      localStorage.setItem("admin_session", "true")
      localStorage.setItem("admin_login_time", new Date().toISOString())

      console.log("[v0] Session stored, redirecting to dashboard")

      // Redirect to dashboard
      router.push("/admin/dashboard")
    } catch (error: unknown) {
      console.error("[v0] Login error:", error)
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-gradient-to-br from-gray-900 via-black to-gray-800 p-6">
      <div className="w-full max-w-md">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col items-center gap-2 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-yellow-500 to-yellow-600 shadow-lg shadow-yellow-500/50">
              <Shield className="h-8 w-8 text-black" />
            </div>
            <h1 className="text-2xl font-bold text-yellow-500">Data Control Section</h1>
            <p className="text-sm text-gray-400">Paavai Engineering College - CSE Department</p>
          </div>

          <Card className="border-yellow-500/20 bg-black/40 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-xl text-yellow-500">Admin Access</CardTitle>
              <CardDescription className="text-gray-400">
                Enter the control password to access the admin panel
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin}>
                <div className="flex flex-col gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="password" className="text-gray-300">
                      Control Password
                    </Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="Enter VAJRA123"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="border-yellow-500/30 bg-black/60 text-white font-mono placeholder:text-gray-500 focus:border-yellow-500"
                    />
                    <p className="text-xs text-gray-500">Demo password: VAJRA123</p>
                  </div>
                  {error && (
                    <div className="rounded-md bg-red-900/20 border border-red-500/30 p-3 text-sm text-red-400">
                      {error}
                    </div>
                  )}
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 text-black font-semibold hover:from-yellow-600 hover:to-yellow-700 shadow-lg shadow-yellow-500/30"
                    disabled={isLoading}
                  >
                    {isLoading ? "Verifying..." : "Access Control Panel"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          <div className="rounded-lg border border-yellow-500/20 bg-yellow-900/10 backdrop-blur-sm p-4">
            <p className="text-xs text-gray-400">
              <strong className="text-yellow-500">Note:</strong> This is a demonstration system for academic project
              purposes. The password (VAJRA123) is used for evaluation and demo purposes only.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
