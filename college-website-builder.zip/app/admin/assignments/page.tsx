import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { AdminHeader } from "@/components/admin/admin-header"
import { Card, CardContent } from "@/components/ui/card"

export default async function AssignmentsPage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user || !data.user.user_metadata?.is_admin) {
    redirect("/admin/login")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader />
      <main className="container mx-auto p-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Assignments Management</h1>
          <p className="text-gray-600 mt-1">Create and evaluate assignments</p>
        </div>
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-gray-500">Assignment management interface coming soon...</p>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
