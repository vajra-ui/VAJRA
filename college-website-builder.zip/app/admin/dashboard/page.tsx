"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, GraduationCap, Calendar, BookOpen, Award, FileText, TrendingUp, Settings, LogOut } from "lucide-react"
import Link from "next/link"

export default function AdminDashboardPage() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    console.log("[v0] Checking admin session")
    const adminSession = localStorage.getItem("admin_session")
    console.log("[v0] Admin session value:", adminSession)

    if (adminSession !== "true") {
      console.log("[v0] No valid session, redirecting to login")
      router.push("/admin/login")
    } else {
      console.log("[v0] Valid session found")
      setIsAuthenticated(true)
    }
  }, [router])

  const handleLogout = () => {
    console.log("[v0] Logging out")
    localStorage.removeItem("admin_session")
    localStorage.removeItem("admin_login_time")
    router.push("/admin/login")
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <p className="text-yellow-500">Verifying access...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800">
      <div className="border-b border-yellow-500/20 bg-black/40 backdrop-blur-sm">
        <div className="container mx-auto flex h-16 items-center justify-between px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-yellow-500 to-yellow-600">
              <Settings className="h-5 w-5 text-black" />
            </div>
            <h1 className="text-xl font-bold text-yellow-500">Control Panel</h1>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="border-yellow-500/30 bg-black/60 text-yellow-500 hover:bg-yellow-500 hover:text-black"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>

      <main className="container mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-yellow-500">Data Control Section</h1>
          <p className="text-gray-400 mt-2">Manage all academic and website data from this central dashboard</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Link href="/admin/students">
            <Card className="border-yellow-500/20 bg-black/40 backdrop-blur-sm hover:border-yellow-500/40 hover:shadow-lg hover:shadow-yellow-500/20 transition-all cursor-pointer h-full">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-yellow-500">Students</CardTitle>
                <GraduationCap className="h-5 w-5 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">Manage</div>
                <p className="text-xs text-gray-400">Student records and data</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/faculty">
            <Card className="border-yellow-500/20 bg-black/40 backdrop-blur-sm hover:border-yellow-500/40 hover:shadow-lg hover:shadow-yellow-500/20 transition-all cursor-pointer h-full">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-yellow-500">Faculty</CardTitle>
                <Users className="h-5 w-5 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">Manage</div>
                <p className="text-xs text-gray-400">Faculty profiles and details</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/attendance">
            <Card className="border-yellow-500/20 bg-black/40 backdrop-blur-sm hover:border-yellow-500/40 hover:shadow-lg hover:shadow-yellow-500/20 transition-all cursor-pointer h-full">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-yellow-500">Attendance</CardTitle>
                <Calendar className="h-5 w-5 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">Manage</div>
                <p className="text-xs text-gray-400">Track attendance records</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/assignments">
            <Card className="border-yellow-500/20 bg-black/40 backdrop-blur-sm hover:border-yellow-500/40 hover:shadow-lg hover:shadow-yellow-500/20 transition-all cursor-pointer h-full">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-yellow-500">Assignments</CardTitle>
                <BookOpen className="h-5 w-5 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">Manage</div>
                <p className="text-xs text-gray-400">Create and evaluate assignments</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/events">
            <Card className="border-yellow-500/20 bg-black/40 backdrop-blur-sm hover:border-yellow-500/40 hover:shadow-lg hover:shadow-yellow-500/20 transition-all cursor-pointer h-full">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-yellow-500">Events</CardTitle>
                <Calendar className="h-5 w-5 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">Manage</div>
                <p className="text-xs text-gray-400">Schedule and organize events</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/achievements">
            <Card className="border-yellow-500/20 bg-black/40 backdrop-blur-sm hover:border-yellow-500/40 hover:shadow-lg hover:shadow-yellow-500/20 transition-all cursor-pointer h-full">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-yellow-500">Achievements</CardTitle>
                <Award className="h-5 w-5 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">Manage</div>
                <p className="text-xs text-gray-400">Track student achievements</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/placements">
            <Card className="border-yellow-500/20 bg-black/40 backdrop-blur-sm hover:border-yellow-500/40 hover:shadow-lg hover:shadow-yellow-500/20 transition-all cursor-pointer h-full">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-yellow-500">Placements</CardTitle>
                <TrendingUp className="h-5 w-5 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">Manage</div>
                <p className="text-xs text-gray-400">Placement records and stats</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/admin/announcements">
            <Card className="border-yellow-500/20 bg-black/40 backdrop-blur-sm hover:border-yellow-500/40 hover:shadow-lg hover:shadow-yellow-500/20 transition-all cursor-pointer h-full">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-yellow-500">Announcements</CardTitle>
                <FileText className="h-5 w-5 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">Manage</div>
                <p className="text-xs text-gray-400">Post announcements</p>
              </CardContent>
            </Card>
          </Link>
        </div>

        <div className="mt-8">
          <Card className="border-yellow-500/20 bg-black/40 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-yellow-500">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-4">
              <Link href="/admin/announcements">
                <Button
                  variant="outline"
                  className="border-yellow-500/30 bg-black/60 text-yellow-500 hover:bg-yellow-500 hover:text-black"
                >
                  <FileText className="mr-2 h-4 w-4" />
                  Post Announcement
                </Button>
              </Link>
              <Link href="/admin/timetable">
                <Button
                  variant="outline"
                  className="border-yellow-500/30 bg-black/60 text-yellow-500 hover:bg-yellow-500 hover:text-black"
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  Update Timetable
                </Button>
              </Link>
              <Link href="/admin/certificates">
                <Button
                  variant="outline"
                  className="border-yellow-500/30 bg-black/60 text-yellow-500 hover:bg-yellow-500 hover:text-black"
                >
                  <Award className="mr-2 h-4 w-4" />
                  Issue Certificate
                </Button>
              </Link>
              <Link href="/admin/settings">
                <Button
                  variant="outline"
                  className="border-yellow-500/30 bg-black/60 text-yellow-500 hover:bg-yellow-500 hover:text-black"
                >
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
